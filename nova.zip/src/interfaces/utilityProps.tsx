export interface ISvgProps {
  nameClass?: string;
}

export interface IAppViewer {
  pathToModel: string;
}
